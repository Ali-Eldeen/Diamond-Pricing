import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder,MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import roc_curve, auc
data = pd.read_csv('/content/diamonds.csv')
data
data = data.drop(data.columns[0], axis=1)
data
nulldata = data.isnull().sum()
print(nulldata)
print(f"Cuts: {len(data['cut'].unique())}")
print(f"Colors: {len(data['color'].unique())}")
print(f"Clarities: {len(data['clarity'].unique())}")
encoder = LabelEncoder()
data['cut'] = encoder.fit_transform(data['cut'])
cut_mappings = {index: label for index, label in enumerate(encoder.classes_)}
data['color'] = encoder.fit_transform(data['color'])
color_mappings = {index: label for index, label in enumerate(encoder.classes_)}
data['clarity'] = encoder.fit_transform(data['clarity'])
clarity_mappings = {index: label for index, label in enumerate(encoder.classes_)}
print(cut_mappings)
print(color_mappings)
print(clarity_mappings)
X = data.drop('price', axis=1)
y = data['price']
X
y
scaler = MinMaxScaler()
X = scaler.fit_transform(X)
X
pd.DataFrame(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
model = LinearRegression()
model.fit(X_train,y_train)
accuracy =  model.score(X_test,y_test)
y_pred = model.predict(X_test)
print(f"Accuracy :{accuracy}")
plt.bar(["Linear Regression"], [accuracy])
plt.xlabel("Model")
plt.ylabel("Accuracy")
plt.title("Model Accuracy")
plt.show()
plt.pie([accuracy, 1 - accuracy], labels=["Accuracy", "Lost"], autopct='%1.1f%%', startangle=140)
plt.axis('equal')
plt.title("Model Accuracy")
plt.show()
plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred, color='blue', alpha=0.5)
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], color='red', linestyle='--', lw=2)
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.title('Actual vs. Predicted Prices')
plt.show()
